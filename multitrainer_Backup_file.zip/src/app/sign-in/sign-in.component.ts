import { Component } from '@angular/core';
import { LoginService } from '../common_service/login.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css']
})
export class SignInComponent {

  // post Data
  username: string = '';
  // password: string = '';
  message: string = '';

   constructor(private loginservice:LoginService){}


// post Data For using POST API 
    //   onSubmit() {
    //     this.loginservice.postregisterData(this.username, this.password).subscribe({
    //       next: response => {
    //         console.log(alert("login Successful"), response);
    //       },
    //       error: error => {
    //         console.error(alert("Login failed"), error);
    //       }
    //     });
    //  }
    
  //  Get data from API Using GET API 
      // onSubmit(){
      //   this.loginservice.getloginData(this.username,this.password).subscribe({
      //     next: response => {
      //       if(response.success)
      //         {
      //         alert("Login Successful");
      //       }
      //       else{
      //         alert("Login Failed Please Enter Correct Details");
      //       }
      //     },
      //     error: error => {
      //       this.message = 'An error Occured';
      //       console.error('Login Failed', error);
      //     }
      //   });
      // }

      onSubmit() {
        console.log('Form submitted with:', this.username, this.password);
        this.loginservice.getloginData(this.username, this.password).subscribe({
          next: response => {
            console.log('Response:', response);
            if (response.length > 0) { // Check if the response array is not empty
              this.message = 'Login successful';
            } else {
              this.message = 'Login failed';
            }
          },
          error: error => {
            console.error('Login failed', error);
            this.message = 'An error occurred';
          }
        });
      }

  password:any;
  show = false;

  ngOnInit() {
    this.password = 'password';
  }

  onClick() {
    if (this.password === 'password') {
      this.password = 'text';
      this.show = true;
    } else {
      this.password = 'password';
      this.show = false;
    }
  }

}
