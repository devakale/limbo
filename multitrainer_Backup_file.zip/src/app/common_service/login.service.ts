import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

 private APIurl = "http://localhost:3000/users";
 private APIurl1 = "http://localhost:3000/sign-up";
 private demo="https://jsonplaceholder.typicode.com/posts";

  constructor(private http:HttpClient) { }

    postregisterData(username: string, password: string): Observable<any> {
      const body = { username, password};
      return this.http.post(this.APIurl, body);
    }

    getloginData(username: string, password: string): Observable<any> {
      let params = new HttpParams();
      params = params.append('username', username);
      params = params.append('password', password);
  
      return this.http.get(this.APIurl, { params });
    }

    postsignupdata(Signup:any):Observable<any>{
      return this.http.post<any>(this.APIurl1,Signup);
    }

    getpostsdata():Observable<any>{
      return this.http.get<any>(this.demo);
    }

}
