import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, retry } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  private APIURL="http://localhost:3000/trainer";

  private CategoryURL="http://localhost:1000/category";

  private Cousers_API="http://localhost:1000/course"




  constructor(private http:HttpClient) { }

  // Category API Code Start From here

  postCategory(name: string, image: File): Observable<any> {
    const formData: FormData = new FormData();
    formData.append('category_name', name);
    formData.append('category_image', image);

    return this.http.post(this.CategoryURL, formData);
  }

  getcategorydata():Observable<any>{
    return this.http.get<any>(this.CategoryURL);
   }

     // Category API Code End here


  // Courses API Code Start From here

      // postcoursesdata(postdata:any):Observable<any>{
      //   return this.http.post<any>(this.Cousers_API,postdata)
      // }

      postcoursesdata(courseData: FormData): Observable<any> {
        return this.http.post(this.Cousers_API, courseData);
      }

      getcoursedata():Observable<any>{
        return this.http.get(this.Cousers_API);
      }


  gettrainerdata():Observable<any>{
    return this.http.get<any>(this.APIURL);
  }


}
