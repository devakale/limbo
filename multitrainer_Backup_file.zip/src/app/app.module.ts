  import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HeaderComponent } from './header/header.component';
import { RelevanceComponent } from './relevance/relevance.component';
import { CoursesComponent } from './courses/courses.component';
import { TrainerComponent } from './trainer/trainer.component';
import { ShopComponent } from './shop/shop.component';
import { CartComponent } from './cart/cart.component';
import { SignInComponent } from './sign-in/sign-in.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { CourseDetailsComponent } from './course-details/course-details.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RelevanceDataComponent } from './relevance-data/relevance-data.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SeeallcategoriesComponent } from './seeallcategories/seeallcategories.component';
import { SeealltrainerComponent } from './seealltrainer/seealltrainer.component';
import { GalleryComponent } from './gallery/gallery.component';
import { AdminDashboardComponent } from './admin/admin-dashboard/admin-dashboard.component';
import { AdminDashboardCategoriesComponent } from './admin/admin-dashboard-categories/admin-dashboard-categories.component';
import { AdminHomeComponent } from './admin/admin-home/admin-home.component';
import { AdminCoursesComponent } from './admin/admin-courses/admin-courses.component';
import { InstructorComponent } from './admin/instructor/instructor.component';
import { TrainerHomeComponent } from './trainer_dashboard/trainer-home/trainer-home.component';
import { PracticeComponent } from './practice/practice.component';
import { CourseenrollComponent } from './courseenroll/courseenroll.component';
import { EnrollNowComponent } from './enroll-now/enroll-now.component';
import { EdittrainerComponent } from './edittrainer/edittrainer.component'; // Import FormsModule



@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    HeaderComponent,
    RelevanceComponent,
    CoursesComponent,
    TrainerComponent,
    ShopComponent,
    CartComponent,
    SignInComponent,
    ForgotPasswordComponent,
    SignUpComponent,
    CourseDetailsComponent,
    RelevanceDataComponent,
    SeeallcategoriesComponent,
    SeealltrainerComponent,
    GalleryComponent,
    AdminDashboardComponent,
    AdminDashboardCategoriesComponent,
    AdminHomeComponent,
    AdminCoursesComponent,
    InstructorComponent,
    TrainerHomeComponent,
    PracticeComponent,
    CourseenrollComponent,
    EnrollNowComponent,
    EdittrainerComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
