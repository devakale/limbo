import { Component } from '@angular/core';

@Component({
  selector: 'app-seealltrainer',
  templateUrl: './seealltrainer.component.html',
  styleUrls: ['./seealltrainer.component.css']
})
export class SeealltrainerComponent {

}
