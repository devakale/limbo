import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SignInComponent } from './sign-in/sign-in.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { RelevanceComponent } from './relevance/relevance.component';
import { RelevanceDataComponent } from './relevance-data/relevance-data.component';
import { CoursesComponent } from './courses/courses.component';
import { TrainerComponent } from './trainer/trainer.component';
import { CourseDetailsComponent } from './course-details/course-details.component';
import { SeeallcategoriesComponent } from './seeallcategories/seeallcategories.component';
import { SeealltrainerComponent } from './seealltrainer/seealltrainer.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ShopComponent } from './shop/shop.component';
import { GalleryComponent } from './gallery/gallery.component';
import { AdminHomeComponent } from './admin/admin-home/admin-home.component';
import { AdminDashboardCategoriesComponent } from './admin/admin-dashboard-categories/admin-dashboard-categories.component';
import { AdminCoursesComponent } from './admin/admin-courses/admin-courses.component';
import { InstructorComponent } from './admin/instructor/instructor.component';
import { EnrollNowComponent } from './enroll-now/enroll-now.component';
import { CourseenrollComponent } from './courseenroll/courseenroll.component';
import { TrainerHomeComponent } from './trainer_dashboard/trainer-home/trainer-home.component';
import { AdminDashboardComponent } from './admin/admin-dashboard/admin-dashboard.component';
import { EdittrainerComponent } from './edittrainer/edittrainer.component';

const routes: Routes = [

  // Routing For Admin Dashboard
  { path:"admin",component:AdminDashboardComponent,

    children:[
      { path:"",component:AdminHomeComponent},
      { path:"adminhome",component:AdminHomeComponent},
      { path:"admincategory",component:AdminDashboardCategoriesComponent},
      { path:"admincourse",component:AdminCoursesComponent},
      { path:"instructors",component:InstructorComponent},
      
    ]
   },

   //  Routing For Trainer Dashboard
      {path:"trainer",component:TrainerHomeComponent},
      {path:"edit",component:EdittrainerComponent},

  //  Routing For User Dashboard

  {path:"", component:DashboardComponent},
  {path:"signin", component:SignInComponent},
  {path:"signup",component:SignUpComponent},
  {path:"forgotfassword",component:ForgotPasswordComponent},
  {path:"seeallcategories",component:SeeallcategoriesComponent},
  {path:"courcedetails", component:CourseDetailsComponent},
  {path:"shop",component:ShopComponent},
  {path:"gallery",component:GalleryComponent},
  {path:"relevance",component:RelevanceComponent,
    children:[
      {path:"",component:RelevanceDataComponent},
      {path:"relevancedata",component:RelevanceDataComponent},
      {path:"courses",component:CoursesComponent},
      {path:"trainer",component:TrainerComponent},
    ]
  },
  {path:"couserenroll",component:CourseenrollComponent},
  {path:"enrollNow",component:EnrollNowComponent}
   
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
