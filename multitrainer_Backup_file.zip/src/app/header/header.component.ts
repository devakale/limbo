import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {
  searchQuery: string = '';
  dropdownVisible: boolean = false;
  
  

  constructor(private router: Router) {}

  showDropdown() {
    this.dropdownVisible = true;
  }

  selectOption(option: string, route: string) {
    this.searchQuery = option;
    this.dropdownVisible = false;
    this.router.navigate([route]);
  }
}
