import { Component, OnInit } from '@angular/core';
import { LoginService } from '../common_service/login.service';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {

 
  showPassword: boolean = false;
  password: string = 'password'; 

   userData= {
    id:' ',
      name:' ',
      username:' ',
      email:' ',
      passwords:' ',
      mobileno:' ',
      altermobo:' ',
      address1:' ',
      address2:' ',
      city:' ',
      state:' ',
      pincode:' ',
      country:' ',

  }
  constructor(private loginservices:LoginService){ }

      ngOnInit() { }

          onSignUp(){
              this.loginservices.postsignupdata(this.userData).subscribe({
                next: (response) => {
                  console.log(alert("Success"),response);
                },
                error: (error)=>{
                  console.log(alert("Error"),error);
                } 
              });
          }

       // Hide And Show Password Logic
            togglePassword(event: Event) {
              event.preventDefault(); 
              this.showPassword = !this.showPassword;
              this.password = this.showPassword ? 'text' : 'password';
            }

}
