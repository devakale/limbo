import { Component } from '@angular/core';

@Component({
  selector: 'app-relevance-data',
  templateUrl: './relevance-data.component.html',
  styleUrls: ['./relevance-data.component.css']
})
export class RelevanceDataComponent {

}
