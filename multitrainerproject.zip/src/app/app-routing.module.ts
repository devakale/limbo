import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SignInComponent } from './sign-in/sign-in.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { RelevanceComponent } from './relevance/relevance.component';
import { RelevanceDataComponent } from './relevance-data/relevance-data.component';
import { CoursesComponent } from './courses/courses.component';
import { TrainerComponent } from './trainer/trainer.component';
import { CourseDetailsComponent } from './course-details/course-details.component';

const routes: Routes = [
  {path:"signin", component:SignInComponent},
  {path:"signup",component:SignUpComponent},
  {path:"forgotfassword",component:ForgotPasswordComponent},
  {path:"",component:RelevanceComponent},
  // {path:"courcedetails",component:CourseDetailsComponent},
  {path:"relevance",component:RelevanceComponent,
    children:[
      // {path:"",component:RelevanceDataComponent},
      {path:"relevancedata",component:RelevanceDataComponent},
      {path:"courses",component:CoursesComponent},
      {path:"trainer",component:TrainerComponent},
    ]
    
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
